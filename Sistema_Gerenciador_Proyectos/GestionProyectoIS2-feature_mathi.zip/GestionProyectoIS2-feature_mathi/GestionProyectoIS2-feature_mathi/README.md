# GestionProyectoIS2
Integrantes
- Mónica Espínola
- Rafael Pukall
- Luján Mir
- Mathías Avalos
