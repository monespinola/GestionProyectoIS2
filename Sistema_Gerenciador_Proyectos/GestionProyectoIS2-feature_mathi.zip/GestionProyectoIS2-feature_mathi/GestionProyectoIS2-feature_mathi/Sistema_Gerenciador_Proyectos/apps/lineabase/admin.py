from django.contrib import admin
from apps.lineabase.models import Lineabase

# Register your models here.
admin.site.register(Lineabase)