from django.apps import AppConfig


class LineabaseConfig(AppConfig):
    name = 'lineabase'
