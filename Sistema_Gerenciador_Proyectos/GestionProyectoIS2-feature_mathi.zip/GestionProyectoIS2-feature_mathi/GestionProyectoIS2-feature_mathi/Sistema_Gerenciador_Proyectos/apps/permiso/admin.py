from django.contrib import admin
from apps.permiso.models import Permiso

# Register your models here.
#admin.site.register(Permiso)
