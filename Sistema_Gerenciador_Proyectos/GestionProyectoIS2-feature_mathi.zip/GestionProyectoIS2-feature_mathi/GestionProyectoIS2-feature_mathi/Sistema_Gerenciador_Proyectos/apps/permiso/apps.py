from django.apps import AppConfig


class PermisoConfig(AppConfig):
    name = 'permiso'
