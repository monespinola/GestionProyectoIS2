from django.contrib import admin
from apps.proyecto.models import Proyecto
# Register your models here.
admin.site.register(Proyecto)

