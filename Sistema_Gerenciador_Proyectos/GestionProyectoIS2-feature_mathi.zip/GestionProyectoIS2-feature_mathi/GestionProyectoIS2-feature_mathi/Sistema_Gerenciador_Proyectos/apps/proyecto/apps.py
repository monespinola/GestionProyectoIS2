from django.apps import AppConfig


class ProyectoConfig(AppConfig):
    name = 'proyecto'
