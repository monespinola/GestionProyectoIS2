from django.apps import AppConfig


class TareaConfig(AppConfig):
    name = 'tarea'
